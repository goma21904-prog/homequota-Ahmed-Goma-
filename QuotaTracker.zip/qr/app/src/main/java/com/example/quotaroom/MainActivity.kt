package com.example.quotaroom

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("quota", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); render() }

    private fun hasAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun cycleStart(day: Int): Long {
        val c = Calendar.getInstance()
        val d = day.coerceIn(1, 28)
        if (c.get(Calendar.DAY_OF_MONTH) < d) c.add(Calendar.MONTH, -1)
        c.set(Calendar.DAY_OF_MONTH, d)
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun bytes(type: Int, from: Long): Long {
        val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        return try {
            val s = nsm.querySummaryForDevice(type, null, from, System.currentTimeMillis())
            s.rxBytes + s.txBytes
        } catch (e: Exception) { 0L }
    }

    private fun fmt(b: Long): String {
        val mb = b / 1048576.0
        return if (mb >= 1024) "%.2f جيجا".format(mb / 1024) else "%.0f ميجا".format(mb)
    }

    private fun text(s: String, size: Float = 16f, color: Int = Color.parseColor("#12302c")) =
        TextView(this).apply { this.text = s; textSize = size; setTextColor(color); setPadding(0, 12, 0, 12) }

    private fun render() {
        root.removeAllViews()
        root.addView(text("حاسب الباقة", 26f))
        if (!hasAccess()) {
            root.addView(text("عشان التطبيق يحسب الاستهلاك لازم تسمح له بالوصول لإحصائيات الاستخدام. فعّل الخيار الخاص بالتطبيق في الشاشة اللي هتفتح."))
            root.addView(Button(this).apply {
                text = "فتح الإعدادات"
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            })
            return
        }
        val quotaGb = prefs.getFloat("quotaGb", 10f)
        val day = prefs.getInt("day", 1)
        val countWifi = prefs.getBoolean("wifi", false)
        val from = cycleStart(day)
        val mobile = bytes(ConnectivityManager.TYPE_MOBILE, from)
        val wifi = if (countWifi) bytes(ConnectivityManager.TYPE_WIFI, from) else 0L
        val used = mobile + wifi
        val quota = (quotaGb * 1073741824L).toLong()
        val left = (quota - used).coerceAtLeast(0)
        val pct = if (quota > 0) (used * 100 / quota).toInt().coerceIn(0, 100) else 0

        root.addView(text("المتبقي: " + fmt(left), 30f, if (pct >= 100) Color.RED else Color.parseColor("#0e7c6b")))
        root.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = pct })
        root.addView(text("المستهلك " + fmt(used) + " من " + fmt(quota) + " (" + pct + "%)"))
        root.addView(text("داتا الموبايل: " + fmt(mobile) + if (countWifi) "   |   الواي فاي: " + fmt(wifi) else ""))
        if (pct >= 100) root.addView(text("الباقة خلصت.", 18f, Color.RED))
        else if (pct >= 80) root.addView(text("قربت تخلص.", 18f, Color.parseColor("#c9831a")))

        root.addView(text("الإعدادات", 20f))
        val q = EditText(this).apply { hint = "حجم الباقة بالجيجا"; setText(quotaGb.toString()); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val d = EditText(this).apply { hint = "يوم بداية الباقة (1-28)"; setText(day.toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        val w = CheckBox(this).apply { text = "احسب الواي فاي ضمن الباقة"; isChecked = countWifi }
        root.addView(q); root.addView(d); root.addView(w)
        root.addView(Button(this).apply {
            text = "حفظ وتحديث"
            setOnClickListener {
                prefs.edit()
                    .putFloat("quotaGb", q.text.toString().toFloatOrNull() ?: 10f)
                    .putInt("day", d.text.toString().toIntOrNull() ?: 1)
                    .putBoolean("wifi", w.isChecked).apply()
                render()
            }
        })
    }
}
